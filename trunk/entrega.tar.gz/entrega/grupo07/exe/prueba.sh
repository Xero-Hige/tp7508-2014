#!/bin/bash

#echo "COMIENZA PRUEBA"
#echo "$BINDIR"
#echo "$ACEPDIR"
#echo "$MAEDIR"
#echo "$GRUPO"
#echo "$RECHDIR"
echo "$VAR"
